<?PHP // $Id: activitynames.php,v 1.2 2006/11/01 09:44:02 moodler Exp $ 
      // activitynames.php - created with Moodle 1.7 beta + (2006101003)


$string['filtername'] = 'Activity Names Auto-linking';

?>
