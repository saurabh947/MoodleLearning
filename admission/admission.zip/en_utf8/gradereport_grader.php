<?PHP // $Id: gradereport_grader.php,v 1.2.2.1 2009/04/22 08:20:25 nicolasconnault Exp $

$string['modulename'] = 'Grader report';
$string['grader:manage'] = 'Manage the grader report';
$string['grader:view'] = 'View the grader report';
$string['preferences'] = 'Grader report preferences';

?>
