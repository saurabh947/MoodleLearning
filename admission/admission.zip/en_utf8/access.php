<?PHP // $Id: access.php,v 1.8.2.2 2007/12/18 17:26:00 nfreear Exp $ 
      // access.php - created with Moodle 1.7 beta + (2006101003)
      // Accessibility, usability and navigation language file.


$string['access'] = 'Accessibility';
$string['accesshelp'] = 'Accessibility help';
$string['accesskey'] = 'Access key, $a';
$string['accessstatement'] = 'Accessibility statement';
$string['activitynext'] = 'Next activity';
$string['activityprev'] = 'Previous activity';
$string['breadcrumb'] = 'Breadcrumb trail';
$string['currentweek'] = 'This week ';
$string['currenttopic'] = 'This topic ';
$string['monthnext'] = 'Next month';
$string['monthprev'] = 'Previous month';
$string['showblocka'] = 'Show $a block';
$string['hideblocka'] = 'Hide $a block';
$string['sitemap'] = 'Site map';
$string['skipa'] = 'Skip $a';
$string['skipblock'] = 'Skip block';
$string['skipnavigation'] = 'Skip navigation';
$string['tabledata'] = 'Data table, $a';
$string['tablelayout'] = 'Layout table, $a';
$string['tocontent'] = 'Skip to main content';
$string['tonavigation'] = 'Go to navigation';
$string['youarehere'] = 'You are here';

?>
