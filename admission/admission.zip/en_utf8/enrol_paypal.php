<?PHP // $Id: enrol_paypal.php,v 1.4 2006/11/25 18:09:33 skodak Exp $ 
      // enrol_paypal.php - created with Moodle 1.7 beta + (2006101003)


$string['business'] = 'The email address of your business PayPal account';
$string['costorkey'] = 'Please choose one of the following methods of enrolment.';
$string['description'] = 'The PayPal module allows you to set up paid courses.  If the cost for any course is zero, then students are not asked to pay for entry.  There is a site-wide cost that you set here as a default for the whole site and then a course setting that you can set for each course individually. The course cost overrides the site cost.';
$string['enrolname'] = 'PayPal';
$string['paypalaccepted'] = 'PayPal payments accepted';
$string['sendpaymentbutton'] = 'Send payment via PayPal';

?>
