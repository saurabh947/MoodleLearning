<?PHP // $Id: coursereport_stats.php,v 1.1.2.2 2008/11/29 14:30:59 skodak Exp $

$string['stats:view'] = 'View course statistics report';

?>
