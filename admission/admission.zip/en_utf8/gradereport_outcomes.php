<?PHP // $Id: gradereport_outcomes.php,v 1.4 2007/08/26 05:48:27 moodler Exp $ 

$string['addoutcome'] = 'Add an outcome';
$string['courseoutcomes'] = 'Course outcomes';
$string['coursespecoutcome'] = 'Course outcomes';
$string['modulename'] = 'Outcomes report';
$string['usedgradeitem'] = 'Number of grade items';
$string['outcomes:view'] = 'View the outcomes report';
?>
