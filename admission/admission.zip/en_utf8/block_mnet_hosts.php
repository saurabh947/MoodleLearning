<?php // $Id: block_mnet_hosts.php,v 1.1 2007/01/04 03:23:48 martinlanghoff Exp $
$string['mnet_hosts'] = 'Network Servers';
$string['server'] = 'Server';

?>