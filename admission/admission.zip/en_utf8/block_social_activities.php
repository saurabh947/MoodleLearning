<?PHP // $Id: block_social_activities.php,v 1.2 2006/11/01 09:44:03 moodler Exp $ 
      // block_social_activities.php - created with Moodle 1.7 beta + (2006101003)


$string['blockname'] = 'Social Activities';

?>
