<?PHP // $Id: gradeimport_xml.php,v 1.5.2.1 2008/01/10 15:38:47 tjhunt Exp $

$string['errbadxmlformat'] = 'Error - bad XML format';
$string['errduplicateidnumber'] = 'Error - duplicate idnumber';
$string['errincorrectidnumber'] = 'Error - incorrect idnumber';
$string['errduplicategradeidnumber'] = 'Error - there are two grade items with idnumber \'$a\' in this course. This should be impossible.';
$string['errincorrectgradeidnumber'] = 'Error - idnumber \'$a\' from the import file does not match any grade item.';
$string['errincorrectuseridnumber'] = 'Error - idnumber \'$a\' from the import file does not match any user.';
$string['fileurl'] = 'Remote file URL';
$string['modulename'] = 'XML file';
$string['xml:view'] = 'Import grades from XML';
$string['xml:publish'] = 'Publish import grades from XML';

?>
