<?PHP // $Id: gradeexport_xls.php,v 1.4 2007/09/27 06:51:55 skodak Exp $

$string['modulename'] = 'Excel spreadsheet';
$string['xls:view'] = 'Use Excel grade export';
$string['xls:publish'] = 'Publish XLS grade export';

?>
