<?PHP // $Id: block_section_links.php,v 1.2.8.1 2009/12/04 06:40:44 dongsheng Exp $ 
      // block_section_links.php - created with Moodle 1.7 beta + (2006101003)


$string['blockname'] = 'Section Links';
$string['incby1'] = 'Increase by ';
$string['incbydesc1'] = 'This is the value the section is incremented each time a section link is displayed starting at 1.';
$string['incby2'] = 'Alternative Increase by ';
$string['incbydesc2'] = 'This is the value the section is incremented each time a section link is displayed starting at 1.';
$string['jumptocurrenttopic'] = 'Jump to current topic';
$string['jumptocurrentweek'] = 'Jump to current week';
$string['numsections1'] = 'Number of Sections';
$string['numsectionsdesc1'] = 'Once the number of sections in the course reaches this number then the increment by value is used.';
$string['numsections2'] = 'Alternative Number of Sections';
$string['numsectionsdesc2'] = 'Once the number of sections in the course reaches this number then the Alternative increment by value is used.';
$string['topics'] = 'Topics';
$string['weeks'] = 'Weeks';

?>
