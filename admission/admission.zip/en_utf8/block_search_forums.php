<?PHP // $Id: block_search_forums.php,v 1.2 2006/11/01 09:44:03 moodler Exp $ 
      // block_search_forums.php - created with Moodle 1.7 beta + (2006101003)


$string['advancedsearch'] = 'Advanced search';
$string['blocktitle'] = 'Search Forums';

?>
