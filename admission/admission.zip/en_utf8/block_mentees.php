<?PHP 
$string['blockname'] = 'Mentees';
$string['configtitle'] = 'Block title';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newmenteesblock'] = '(new Mentees block)';
?>