<?PHP // $Id: block_course_summary.php,v 1.2 2006/11/01 09:44:02 moodler Exp $ 
      // block_course_summary.php - created with Moodle 1.7 beta + (2006101003)


$string['coursesummary'] = 'Course Summary';
$string['pagedescription'] = 'Course/Site Description';

?>
