<?PHP // $Id: gradeexport_ods.php,v 1.4.2.2 2008/02/17 19:47:48 skodak Exp $

$string['modulename'] = 'OpenDocument spreadsheet';
$string['ods:view'] = 'Use OpenDocument grade export';
$string['ods:publish'] = 'Publish ODS grade export';

?>
