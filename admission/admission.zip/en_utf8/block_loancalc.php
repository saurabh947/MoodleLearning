<?PHP // $Id: block_loancalc.php,v 1.3 2006/11/01 09:44:03 moodler Exp $ 
      // block_loancalc.php - created with Moodle 1.7 beta + (2006101003)


$string['amountofloan'] = 'Amount of loan';
$string['fortnightly'] = 'Fortnightly';
$string['interestrate'] = 'Interest rate';
$string['loancalc'] = 'Loan calculator';
$string['loanterm'] = 'Loan term (years)';
$string['monthly'] = 'Monthly';
$string['repaymentamount'] = 'Repayment amount';
$string['repaymentfreq'] = 'Repayment frequency';
$string['weekly'] = 'Weekly';

?>
