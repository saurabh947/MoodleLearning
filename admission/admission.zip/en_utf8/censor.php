<?PHP // $Id: censor.php,v 1.3 2006/11/01 09:44:03 moodler Exp $ 
      // censor.php - created with Moodle 1.7 beta + (2006101003)


$string['badwords'] = 'shit,fucked,fucker,fuck,dickhead, dick,cockhead,cock,cunt,asshole,arsehole,prick,bitch, jism,whore,slut,wanker, wank,bastard,dildo,masturbate, orgasm,penis,nigger, pussy,vagina';
$string['filtername'] = 'Word Censorship';

?>
