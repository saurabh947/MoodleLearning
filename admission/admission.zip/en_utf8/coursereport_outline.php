<?PHP // $Id: coursereport_outline.php,v 1.1.2.3 2008/11/29 15:08:46 skodak Exp $

$string['outline:view'] = 'View course activity report';

?>
