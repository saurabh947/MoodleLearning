<?PHP // $Id: coursereport_log.php,v 1.1.2.4 2008/11/30 12:07:40 skodak Exp $

$string['log:view'] = 'View course logs';
$string['log:viewlive'] = 'View live logs';
$string['log:viewtoday'] = 'View today\'s logs';

$string['loglive'] = 'Live logs';

?>
