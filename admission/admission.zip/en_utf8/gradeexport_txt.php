<?PHP // $Id: gradeexport_txt.php,v 1.4 2007/09/27 06:51:55 skodak Exp $

$string['modulename'] = 'Plain text file';
$string['txt:view'] = 'Use text grade export';
$string['txt:publish'] = 'Publish TXT grade export';

?>
