<?PHP // $Id: gradeimport_csv.php,v 1.3 2007/08/26 05:48:26 moodler Exp $

$string['modulename'] = 'CSV file';
$string['csv:view'] = 'Import grades from CSV';

?>
