<?php // $Id: datapreset_imagegallery.php,v 1.2 2007/08/21 03:40:20 moodler Exp $
$string['batchname'] = 'Create a new batch here';
?>
