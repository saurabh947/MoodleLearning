<?php

$string['blockname'] = 'Youtube';
$string['configtitle'] = 'Title';
$string['numberofvideos'] = 'Number of videos';
$string['category'] = 'Category';
$string['anycategory'] = 'Any Category';
$string['includeonlyvideosfromplaylist'] = 'Include only videos from the playlist with id';
$string['filmsanimation'] = 'Films &amp; Animation';
$string['autosvehicles'] = 'Autos &amp; Vehicles';
$string['comedy'] = 'Comedy';
$string['education'] = 'Education';
$string['entertainment'] = 'Entertainment';
$string['music'] = 'Music';
$string['newspolitics'] = 'News &amp; Politics';
$string['peopleblogs'] = 'People &amp; Blogs';
$string['petsanimals'] = 'Pets &amp; Animals';
$string['howtodiy'] = 'How-to &amp; DIY';
$string['sports'] = 'Sports';
$string['travel'] = 'Travel &amp; Places';
$string['gadgetsgames'] = 'Gadgets &amp; Games';
$string['scienceandtech'] = 'Science &amp; Tech';

?>
