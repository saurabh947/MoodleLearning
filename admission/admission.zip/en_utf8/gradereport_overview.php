<?PHP // $Id: gradereport_overview.php,v 1.3 2007/08/26 05:48:27 moodler Exp $

$string['modulename'] = 'Overview report';
$string['overview:view'] = 'View the overview report';

?>
