<?PHP // $Id: emailprotect.php,v 1.2 2006/11/01 09:44:04 moodler Exp $ 
      // emailprotect.php - created with Moodle 1.7 beta + (2006101003)


$string['filtername'] = 'Email Protection';

?>
