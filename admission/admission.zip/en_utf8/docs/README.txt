This directory used to contain lots of documentation in HTML form.

All of it has gone now because we now use the Moodle Docs wiki.


To find out the new locations for all the information that was here, see:

    http://docs.moodle.org/19/en/MoodleDocs_and_lang_packs

    http://tracker.moodle.org/browse/MDL-4912

Cheers,
Martin Dougiamas, 10th July 2007
