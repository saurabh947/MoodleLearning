<?php //$Id: bulkusers.php,v 1.5.2.2 2007/11/13 09:02:14 skodak Exp $
$string['allfilteredusers'] = 'All filtered ($a->count/$a->total)';
$string['allselectedusers'] = 'All selected ($a->count/$a->total)';
$string['allusers'] = 'All users ($a)';
$string['available'] = 'Available';
$string['addall'] = 'Add all';
$string['addsel'] = 'Add to selection';
$string['confirmmessage'] = 'Do you really want to send the message above to all these users?<br />$a' ;
$string['noselectedusers'] = 'No users selected';
$string['nofilteredusers'] = 'No users found (0/$a)';
$string['removesel'] = 'Remove from selection';
$string['removeall'] = 'Remove all';
$string['selected'] = 'Selected';
$string['selectedlist'] = 'Selected user list...';
$string['usersfound'] = '$a user(s) found.';
$string['usersinlist'] = 'Users in list';
$string['usersselected'] = '$a user(s) selected.';
