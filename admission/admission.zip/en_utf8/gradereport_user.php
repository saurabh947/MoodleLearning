<?PHP // $Id: gradereport_user.php,v 1.2 2007/07/23 08:13:59 moodler Exp $ 

$string['modulename'] = 'User report';
$string['user:view'] = 'View your own grade report';

?>
