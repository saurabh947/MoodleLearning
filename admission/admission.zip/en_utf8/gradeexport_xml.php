<?PHP // $Id: gradeexport_xml.php,v 1.4 2007/09/27 06:51:55 skodak Exp $

$string['modulename'] = 'XML file';
$string['xml:view'] = 'Use XML grade export';
$string['xml:publish'] = 'Publish XML grade export';

?>
