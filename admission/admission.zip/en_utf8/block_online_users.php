<?PHP // $Id: block_online_users.php,v 1.2.8.2 2008/11/30 15:43:28 skodak Exp $ 
      // block_online_users.php - created with Moodle 1.7 beta + (2006101003)


$string['blockname'] = 'Online Users';
$string['configtimetosee'] = 'Number of minutes determining the period of inactivity after which a user is no longer considered to be online.';
$string['online_users:viewlist'] = 'View list of online users';
$string['periodnminutes'] = 'last $a minutes';
$string['timetosee'] = 'Remove after inactivity (minutes)';

?>
