<?php

$string['blockname'] = 'Flickr';
$string['configtitle'] = 'Title';
$string['getfromphotoset'] = 'Get photos from photoset with id';
$string['date-posted-asc'] = 'Date Posted ASC';
$string['date-posted-desc'] = 'Date Posted DESC';
$string['date-taken-asc'] = 'Date Taken ASC';
$string['date-taken-desc'] = 'Date Taken DESC';
$string['defaulttile'] = 'Flickr';
$string['includerelatedtags'] = 'Include related tags in query';
$string['interestingness-asc'] = 'Interestingness ASC';
$string['interestingness-desc'] = 'Interestingness DESC';
$string['numberofphotos'] = 'Number of photos';
$string['relevance'] = 'Relevance';
$string['sortby'] = 'Sort by';
                                   
?>
