<?PHP // $Id: block_html.php,v 1.2 2006/11/01 09:44:03 moodler Exp $ 
      // block_html.php - created with Moodle 1.7 beta + (2006101003)


$string['configcontent'] = 'Content';
$string['configtitle'] = 'Block Title';
$string['html'] = 'HTML';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newhtmlblock'] = '(new HTML block)';

?>
